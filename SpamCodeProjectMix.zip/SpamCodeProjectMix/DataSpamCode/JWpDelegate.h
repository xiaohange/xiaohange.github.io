#import <UIKit/UIKit.h>
@interface JWpDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;

- (void)sp_getUsersMostFollowerSuccess;

- (void)jq_getUserFollowSuccess;

- (void)jq_getUsersMostLikedSuccess;

- (void)jq_didUserInfoFailed;

- (void)jq_upload;

- (void)jq_getUsersMostLikedSuccess;
@end
