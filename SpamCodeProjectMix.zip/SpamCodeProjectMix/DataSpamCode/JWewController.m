#import "JWewController.h"
@interface JWewController ()
@end
@implementation JWewController
- (void)viewDidLoad {
    [super viewDidLoad];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)hello2:(NSString *)say
{
    
}
- (void)hello3:(NSString *)say
{
    
}
- (void)hello4:(NSString *)say
{
    
}
- (void)hello5:(NSString *)say
{
    
}

- (void)sp_getMediaData:(NSString *)isLogin {
    NSLog(@"Get User Succrss");
}

- (void)jq_getUsersMostLikedSuccess:(NSString *)string {
    NSLog(@"Get Info Success");
}

- (void)jq_upload:(NSString *)isLogin {
    NSLog(@"Get User Succrss");
}

- (void)jq_getUsersMostFollowerSuccess:(NSString *)followCount {
    NSLog(@"Continue");
}

@end
