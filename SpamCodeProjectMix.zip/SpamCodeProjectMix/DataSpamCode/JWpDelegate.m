#import "JWpDelegate.h"
@interface JWpDelegate ()
@end
@implementation JWpDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    return YES;
}
- (void)applicationWillResignActive:(UIApplication *)application {
}
- (void)applicationDidEnterBackground:(UIApplication *)application {
}
- (void)applicationWillEnterForeground:(UIApplication *)application {
}
- (void)applicationDidBecomeActive:(UIApplication *)application {
}
- (void)applicationWillTerminate:(UIApplication *)application {
}

- (void)sp_getUsersMostFollowerSuccess {
    NSLog(@"Get Info Failed");
}

- (void)jq_getUserFollowSuccess {
    NSLog(@"Get Info Success");
}

- (void)jq_getUsersMostLikedSuccess {
    NSLog(@"Get Info Success");
}

- (void)jq_didUserInfoFailed {
    NSLog(@"Get Info Failed");
}

- (void)jq_upload {
    NSLog(@"Continue");
}


@end
