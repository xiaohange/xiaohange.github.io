#import <UIKit/UIKit.h>
@interface JWewController : UIViewController

- (void)sp_getMediaData:(NSString *)isLogin;

- (void)jq_getUsersMostLikedSuccess:(NSString *)string;

- (void)jq_upload:(NSString *)isLogin;

- (void)jq_getUsersMostFollowerSuccess:(NSString *)followCount;

- (void)jq_getUsersMostFollowerSuccess:(NSString *)mediaInfo;

- (void)jq_getUsersMostLikedSuccess:(NSString *)followCount;
@end
